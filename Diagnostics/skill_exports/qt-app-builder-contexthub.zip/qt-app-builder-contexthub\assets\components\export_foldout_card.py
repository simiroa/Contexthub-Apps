from __future__ import annotations

from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget

from contexthub.ui.qt.shell import get_shell_metrics, set_button_role


def build_export_foldout_card(title: str = "Export", *, expanded: bool = False) -> dict[str, object]:
    m = get_shell_metrics()
    card = QFrame()
    card.setObjectName("card")
    layout = QVBoxLayout(card)
    layout.setContentsMargins(m.panel_padding, m.panel_padding, m.panel_padding, m.panel_padding)
    layout.setSpacing(8)

    title_label = QLabel(title)
    title_label.setObjectName("sectionTitle")
    layout.addWidget(title_label)

    details = QWidget()
    details_layout = QVBoxLayout(details)
    details_layout.setContentsMargins(0, 0, 0, 0)
    details_layout.setSpacing(8)
    status_label = QLabel("Ready")
    status_label.setObjectName("summaryText")
    progress_label = QLabel("")
    progress_label.setObjectName("summaryText")
    details_layout.addWidget(status_label)
    details_layout.addWidget(progress_label)
    layout.addWidget(details)

    action_row = QHBoxLayout()
    action_row.setSpacing(6)
    reveal_btn = QPushButton("Open")
    set_button_role(reveal_btn, "secondary")
    cancel_btn = QPushButton("Cancel")
    set_button_role(cancel_btn, "ghost")
    run_btn = QPushButton(title)
    set_button_role(run_btn, "primary")
    toggle_btn = QPushButton("^" if expanded else "v")
    toggle_btn.setCheckable(True)
    toggle_btn.setChecked(expanded)
    toggle_btn.setObjectName("iconBtn")
    action_row.addWidget(reveal_btn, 0)
    action_row.addWidget(cancel_btn, 0)
    action_row.addWidget(run_btn, 1)
    action_row.addWidget(toggle_btn, 0)
    layout.addLayout(action_row)

    def _sync() -> None:
        is_open = toggle_btn.isChecked()
        toggle_btn.setText("^" if is_open else "v")
        details.setVisible(is_open)

    toggle_btn.clicked.connect(_sync)
    _sync()

    return {
        "card": card,
        "title_label": title_label,
        "toggle_btn": toggle_btn,
        "details": details,
        "details_layout": details_layout,
        "reveal_btn": reveal_btn,
        "cancel_btn": cancel_btn,
        "run_btn": run_btn,
        "status_label": status_label,
        "progress_label": progress_label,
    }
