# __APP_NAME__

## Purpose

Describe the dense multi-panel workflow.

## Inputs

- List supported file or selection inputs.

## Panels

- Explain what each major panel does.

## Output

- Explain what the run/export section writes or updates.
