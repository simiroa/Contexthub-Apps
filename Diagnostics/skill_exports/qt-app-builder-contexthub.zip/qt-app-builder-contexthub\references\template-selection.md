# Template Selection

Choose `ui.template` before writing code.

## mini

Use `mini` when all of these are true:

- single task or confirmation flow
- no large preview/list workspace
- no bottom size grip
- window behaves more like a focused tool or dialog

Typical patterns:

- one short form
- one summary block
- one main CTA

Do not use `mini` for apps that need queue management, dual panes, or large persistent previews.

## compact

Use `compact` when:

- the UI is one-column
- input, current status, and execution are the main behaviors
- preview exists but is secondary
- execution is simple enough to fit in a short vertical flow

Typical patterns:

- source URL + preview + download
- input files + small options + execute
- tool-like runner shell

Compact must still use the standard frameless shell and bottom size grip.

## full

Use `full` when:

- the app needs a splitter or dense multi-panel layout
- preview/list/parameters/output are separated
- the UI benefits from simultaneous inspection of multiple zones

Typical patterns:

- list + preview + parameter panel
- left/right workspace split
- compare/convert/editor-like screens that are still template-friendly

Full must use the standard frameless shell and bottom size grip.

## special

Use `special` only when interaction rules are not well expressed by the normal templates.

Examples:

- dashboard
- review workspace
- comparison matrix
- studio workspace

Allowed exceptions:

- bespoke panel model
- domain-specific interaction flow

Not allowed:

- bespoke theme
- alternate header contract
- removing grip from non-mini windows without a deliberate runtime-level exception

## Selection Heuristic

If uncertain:

- choose `compact` before `full`
- choose `full` before `special`
- choose `mini` only when the window can stay intentionally small without scroll-heavy body content
