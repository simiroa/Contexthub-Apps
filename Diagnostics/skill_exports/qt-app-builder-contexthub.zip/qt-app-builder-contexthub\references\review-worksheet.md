# Review Worksheet

Use this worksheet when testing whether the skill classified or assembled a Qt app correctly.

## Review Header

- Prompt:
- Proposed template:
- Proposed category:
- Closest existing app:

## Bucket Decision

- Why this bucket fits:
- Why the next closest bucket does not fit:

## Component Decision

- Required components chosen:
- Optional components chosen:
- Any bespoke component introduced:
- Why shared runtime components were insufficient, if applicable:

## Contract Checks

- `ui.framework = pyside6`:
- `ui.shared_theme = contexthub`:
- `ui.template` explicit:
- `HeaderSurface`:
- `attach_size_grip` rule:
- raw color avoided:
- `surfaceRole="content"` rule considered:

## Result

- Pass / Fail:
- Corrections needed:
- References to update:
