# Component Catalog

Build new Qt apps by composing a small set of standard blocks.

## Shell Components

### HeaderSurface

Use for every Qt app window header.

Rules:

- app name only
- icon buttons only
- no subtitle row by default
- no open button by default

### attach_size_grip

Use on all non-mini templates.

Call:

- `attach_size_grip(shell_layout, window_shell)`

Do not create a custom grip row in app code unless the shared helper is being extended.

## Surface Components

### InputCard

Use for source path, URL, drop target, or light form input.

Recommended content:

- short section title
- one main field row
- optional secondary CTA

### PreviewCard

Use when the app needs a visible preview or current inspected state.

Rules:

- large empty areas should use `subtle` or preview-specific inset, not raw field background
- for compact apps, keep preview secondary and shallow

Starter snippet:

- `assets/components/preview_card.py`

### StatusCard

Use for current state, summary, dependency readiness, or analysis result.

Rules:

- short text only
- prefer summary tone, not dense controls

### QueueCard

Use only when the product genuinely has queued work items.

Rules:

- short list or capped scroll area
- compact apps should keep queue height restrained

Starter snippet:

- `assets/components/queue_card.py`

### QueueManagerCard

Use when queueing is a first-class product concept and the app needs queue controls beyond a short list.

Starter snippet:

- `assets/components/queue_manager_card.py`

### ExecutionCard

Use for output directory, progress, status, and primary action.

Rules:

- should be integrated with options in compact flows when separation adds no value
- keep a single main CTA

Starter snippet:

- `assets/components/execution_card.py`

### EmptyStateCard

Use for empty list, empty preview, or zero-detected states when a full preview is not appropriate.

Starter snippet:

- `assets/components/empty_state_card.py`

## Panel Components

### FixedParameterPanel

Use for constrained option sets and preset-driven forms.

Best fit:

- compact settings
- format choice
- small parameter groups

### PreviewListPanel

Use for full-template list + preview layouts.

Best fit:

- file lists
- gallery plus preview
- left panel asset browsing

### ExportRunPanel

Use when the app genuinely needs an output/export section distinct from option entry.

Do not force it into compact apps if a simpler execution section is cleaner.

### ComparativePreviewWidget

Use only when side-by-side or comparative image preview is a real feature, not as a generic preview placeholder.

## Domain Preview Components

### ImagePreviewCard

Use for single-image preview with lightweight metadata.

Starter snippet:

- `assets/components/image_preview_card.py`

### AudioPreviewCard

Use for waveform/player-style preview surfaces.

Starter snippet:

- `assets/components/audio_preview_card.py`

### VideoPreviewCard

Use for thumbnail/player preview with duration/resolution metadata.

Starter snippet:

- `assets/components/video_preview_card.py`

### DocumentPreviewCard

Use for page thumbnail and page-count/OCR summaries.

Starter snippet:

- `assets/components/document_preview_card.py`

### Viewport3DCard

Use for mesh/model preview shells and 3D status.

Starter snippet:

- `assets/components/viewport_3d_card.py`

## Input And Batch Components

### DropZoneCard

Use for drag-and-drop oriented input areas.

Starter snippet:

- `assets/components/drop_zone_card.py`

### BatchListCard

Use when a real list of queued or batched inputs is needed.

Starter snippet:

- `assets/components/batch_list_card.py`

### PromptCard

Use for longer prompt or instruction text entry.

Starter snippet:

- `assets/components/prompt_card.py`

### HistoryPanel

Use for recent files, session history, or project history.

Starter snippet:

- `assets/components/history_panel.py`

### PresetSelectorCard

Use when presets have their own explanation and selection state.

Starter snippet:

- `assets/components/preset_selector_card.py`

Use above parameter controls when presets define the baseline working mode of a full layout.

### PresetParameterCard

Use when presets and the first parameter group belong to the same working mode and should read as one card.

Starter snippet:

- `assets/components/preset_parameter_card.py`

### ModelSelectorCard

Use when model choice and model state are product-level concerns.

Starter snippet:

- `assets/components/model_selector_card.py`

### ParameterStrip

Use for compact slider-first parameter controls.

Starter snippet:

- `assets/components/parameter_strip.py`

### ParameterControlsCard

Use when parameters exist without a preset block, or when a second parameter card is genuinely needed.

Starter snippet:

- `assets/components/parameter_controls_card.py`

## Execution And State Components

### CollapsibleSection

Use when export or advanced options should stay hidden until needed.

Starter snippet:

- `assets/components/collapsible_section.py`

### ExportFoldoutCard

Use as the default export surface in `full` layouts when export should be collapsible but still keep an always-visible action row.

Starter snippet:

- `assets/components/export_foldout_card.py`

### OutputOptionsCard

Use for output format, naming, and post-run behavior.

Starter snippet:

- `assets/components/output_options_card.py`

### ProgressStatusBar

Use for tight status + progress + main CTA rows.

Starter snippet:

- `assets/components/progress_status_bar.py`

### DependencyStatusCard

Use when runtime dependencies such as ffmpeg, blender, or model services affect usability.

Starter snippet:

- `assets/components/dependency_status_card.py`

### ResultInspectorCard

Use when the user needs to inspect structured output, logs, result fields, or export metadata after execution.

Starter snippet:

- `assets/components/result_inspector_card.py`

## Layout Components

### CompactStack

One-column flow for:

- input
- preview or status
- execution

### FullSplitWorkspace

Two-zone or multi-zone split for:

- preview + input list
- preview + parameters
- workspace + run panel

Starter snippet:

- `assets/components/workspace_split.py`

### SpecialWorkspace

Custom interaction model for dashboards, review workspaces, or matrix-driven tools.

Still required:

- shared header
- shared theme
- shared grip for non-mini

### ToolbarRow

Use for view-mode, filter, and lightweight action rows.

Starter snippet:

- `assets/components/toolbar_row.py`

### CompareWorkspace

Use for left/right, before/after, or compare/diff shells.

Starter snippet:

- `assets/components/compare_workspace.py`

### ChannelMapCard

Use for EXR split/merge and texture packing style channel assignment.

Starter snippet:

- `assets/components/channel_map_card.py`

## Decision Rule

If a new app starts inventing more than one new card type, first check whether the behavior is actually one of the standard components with different content.
