# Template Diffs

This file defines what is intentionally different between the four template buckets.

## Shared Base

All templates share:

- frameless `QMainWindow`
- `windowShell`
- `HeaderSurface`
- shared stylesheet from `build_shell_stylesheet()`
- shared metrics from `get_shell_metrics()`
- `manual.md`
- manifest with explicit `ui.template`

## mini

Body shape:

- short vertical stack
- one or two cards at most
- no grip

Preferred widgets:

- `FixedParameterPanel`
- one small result/status card
- one main CTA

Avoid:

- splitter
- long scroll body
- queue manager

## compact

Body shape:

- one-column stack
- short sections
- execution area integrated into the vertical flow
- grip required

Preferred widgets:

- URL/input card
- preview/status card
- compact options/execution card

Avoid:

- separate heavy export card if options and execution can be one section

## full

Body shape:

- splitter or dense multi-panel layout
- larger preview/list/parameter surfaces
- grip required

Preferred widgets:

- `PreviewListPanel`
- `FixedParameterPanel`
- `CollapsibleSection`
- `ExportFoldoutCard`
- `OutputOptionsCard`
- `ExecutionCard`

Default ordering:

- preview above input list
- combined preset + parameter card first when presets exist
- parameters before export
- export as the bottom-most section
- export hidden behind a collapsible section unless always-visible export is core to the product

## special

Body shape:

- interaction-specific layout
- may use custom workspace widgets
- template skeleton itself should stay close to empty beyond the shared shell
- the main body is expected to be replaced by app-specific components or workspace code
- grip required unless a runtime-level exception is deliberately introduced

Still required:

- shared header
- shared theme
- shared shell and palette rules

## Migration Rule

If converting an old app:

- reduce local styling first
- classify the app into one of the four templates
- only keep `special` when ordinary template constraints genuinely fail
