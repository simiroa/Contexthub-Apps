# Implementation Patterns

Use these patterns to avoid common regressions while building new Qt apps.

## Geometry And Default Size

If a compact or mini app keeps opening larger than intended:

- check `QSettings.restoreGeometry()`
- clamp restored size back to the current default when old saved geometry is clearly oversized
- do not assume `resize(...)` alone will win

## Content Surface Pattern

If card gaps or empty scroll areas expose the wrong background:

- assign `surfaceRole="content"` to the body container
- assign `surfaceRole="content"` to `QScrollArea.viewport()` when the viewport can be exposed
- use `subtle` for secondary inset wells

## Execution Pattern

For compact apps:

- prefer one integrated execution section
- avoid separate heavy options and export cards if they behave like a single run flow
- keep one main CTA

For full apps:

- start the right column with a preset dropdown when the product has reusable working modes
- place the current preview above the input list when both live in the same workspace side
- keep parameters visible first
- keep export as the bottom-most section of the right column
- treat export/output controls as a collapsible section by default unless export is the primary product surface
- prefer an export-specific foldout with always-visible action row over a generic show/hide card
- `FixedParameterPanel` plus a collapsible export/run section is the default unless the product has a better established workspace model

## Preview Pattern

For preview-capable apps:

- keep compact previews shallow and secondary
- avoid large empty canvases without an obvious purpose
- use a status card instead of a preview if the user only needs readiness and result summaries
- for full apps, preview should be visually earlier than the input list

## Queue Pattern

Only add a queue if queued work is a real product concept.

- compact: short capped queue
- full: queue may be a true panel
- mini: no queue

## Special Pattern

Use `special` only when the interaction model is genuinely different.

Still preserve:

- `HeaderSurface`
- shared theme
- non-mini grip
- component names and surface roles where possible
