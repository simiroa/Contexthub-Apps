# __APP_NAME__

## Purpose

Describe the bespoke interaction model and why this app is `special`.

## Workspace

- Explain major zones and user flow.

## Shared Rules

- Header still uses the standard shell header.
- Theme still uses `contexthub`.
- Grip still applies unless there is a runtime-level exception.
