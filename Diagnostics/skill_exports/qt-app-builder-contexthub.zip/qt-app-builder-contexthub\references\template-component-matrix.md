# Template Component Matrix

This matrix defines which components are expected in each template bucket.

| Component | mini | compact | full | special |
| --- | --- | --- | --- | --- |
| `HeaderSurface` | required | required | required | required |
| `attach_size_grip` | forbidden | required | required | required |
| `InputCard` | common | required | common | situational |
| `PreviewCard` | optional | common | common | situational |
| `ImagePreviewCard` | optional | common | common | situational |
| `AudioPreviewCard` | forbidden | situational | situational | situational |
| `VideoPreviewCard` | forbidden | situational | situational | situational |
| `DocumentPreviewCard` | forbidden | situational | situational | situational |
| `Viewport3DCard` | forbidden | forbidden | situational | situational |
| `StatusCard` | common | common | optional | common |
| `QueueCard` | forbidden | optional | optional | situational |
| `QueueManagerCard` | forbidden | forbidden | situational | situational |
| `EmptyStateCard` | common | common | optional | common |
| `ExecutionCard` | common | required | common | situational |
| `CollapsibleSection` | forbidden | optional | common | situational |
| `ExportFoldoutCard` | forbidden | optional | common | situational |
| `OutputOptionsCard` | optional | common | common | situational |
| `ProgressStatusBar` | common | common | common | situational |
| `DependencyStatusCard` | optional | optional | common | situational |
| `ResultInspectorCard` | forbidden | optional | situational | situational |
| `FixedParameterPanel` | optional | common | common | situational |
| `PreviewListPanel` | forbidden | optional | common | situational |
| `BatchListCard` | forbidden | optional | common | situational |
| `DropZoneCard` | optional | common | common | situational |
| `PresetSelectorCard` | optional | common | common | situational |
| `PresetParameterCard` | forbidden | optional | common | situational |
| `ParameterControlsCard` | forbidden | optional | common | situational |
| `PromptCard` | optional | situational | situational | common |
| `HistoryPanel` | forbidden | optional | optional | common |
| `ModelSelectorCard` | forbidden | situational | situational | common |
| `ParameterStrip` | optional | common | situational | situational |
| `ExportRunPanel` | forbidden | optional | common | situational |
| `ComparativePreviewWidget` | forbidden | forbidden | situational | situational |
| `CompactStack` | required | required | forbidden | forbidden |
| `FullSplitWorkspace` | forbidden | forbidden | common | situational |
| `SpecialWorkspace` | forbidden | forbidden | forbidden | common |
| `ToolbarRow` | forbidden | optional | situational | common |
| `CompareWorkspace` | forbidden | forbidden | situational | common |
| `ChannelMapCard` | forbidden | forbidden | situational | situational |

## Template Assembly Guidance

### mini

Use 2-3 blocks total:

- `HeaderSurface`
- one main body card
- one execution/status block

### compact

Default sequence:

- `InputCard`
- `PreviewCard` or `StatusCard`
- integrated `ExecutionCard`
- optional `QueueCard`
- optional `ResultInspectorCard`

Typical example:

- `pdf_merge`

### full

Default sequence:

- `HeaderSurface`
- `FullSplitWorkspace`
- left side with preview first, input list below
- right side starts with one preset+parameter card when presets exist
- right side keeps export as the last section
- optional `QueueManagerCard` or `ResultInspectorCard`

Typical example:

- `video_convert`

### special

Default sequence:

- `HeaderSurface`
- custom workspace root
- standard components inserted where useful

Typical examples:

- `versus_up`
- `qwen3_tts`
- `youtube_downloader`

## Anti-Patterns

- `mini` with large queue or splitter
- `compact` with separate heavy options and export cards when they should be one run section
- `full` without a real reason for multi-panel layout
- `special` used only to avoid choosing between `compact` and `full`
