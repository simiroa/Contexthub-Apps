# Component Roadmap

This roadmap lists the component families that new Qt apps should prefer before inventing app-local UI structures.

## Core Components

- `HeaderSurface`
- `attach_size_grip`
- `InputCard`
- `PreviewCard`
- `StatusCard`
- `QueueCard`
- `ExecutionCard`
- `FullSplitWorkspace`

## Domain Preview Components

- `ImagePreviewCard`
- `AudioPreviewCard`
- `VideoPreviewCard`
- `DocumentPreviewCard`
- `Viewport3DCard`

## Input And Batch Components

- `DropZoneCard`
- `BatchListCard`
- `PromptCard`
- `HistoryPanel`
- `PresetSelectorCard`
- `PresetParameterCard`
- `ModelSelectorCard`
- `ParameterControlsCard`
- `ParameterStrip`

## Execution And State Components

- `CollapsibleSection`
- `ExportFoldoutCard`
- `OutputOptionsCard`
- `ProgressStatusBar`
- `DependencyStatusCard`
- `EmptyStateCard`
- `QueueManagerCard`
- `ResultInspectorCard`

## Special Task Components

- `ToolbarRow`
- `CompareWorkspace`
- `ChannelMapCard`

## Promotion Rule

If the same UI idea appears in more than one app, prefer turning it into a standard component skeleton here before creating another bespoke implementation.
