# Runtime Dependencies And App Skeleton Rules

New Qt apps should reuse the existing category and `_engine` tree whenever possible.

## Category Decision

Before making a new app:

- check if the domain fits an existing category
- inspect the category `_engine/features/...`
- reuse service/state/widgets if they already exist

Do not create new categories for styling reasons.

## Main Wrapper Rules

The app folder `main.py` should stay thin.

Recommended pattern:

- compute `APP_ROOT`
- set up runtime bootstrap paths if the category uses them
- import shared runtime and the actual Qt app entry
- pass file targets into `start_app(...)`

Keep business logic out of the app-folder wrapper unless the feature is genuinely app-local.

## Manifest Rules

Every new Qt app manifest must include:

- stable `id`
- correct `runtime.category`
- correct `execution.entry_point`
- `ui.framework = pyside6`
- `ui.shared_theme = contexthub`
- `ui.template = mini|compact|full|special`

Do not leave `ui.template` inferred for new work.

## Shared Runtime First

Prefer shared runtime components before inventing new panel structures:

- `PreviewListPanel`
- `FixedParameterPanel`
- `ExportRunPanel`
- `ConfirmDialog`

If they are close but not sufficient, extend them or add a shared variant. Do not fork a one-off local version first.
