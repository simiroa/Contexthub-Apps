# __APP_NAME__

## Purpose

Describe the compact one-column workflow.

## Inputs

- Explain the source input.

## Execution

- Explain what the run action does.

## Output

- Explain where results are written or revealed.
