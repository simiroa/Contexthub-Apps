# Validation Checklist

Run these checks for any new or rewritten Qt app.

## Required Checks

1. `python -m py_compile <touched_python_files>`
2. `python dev-tools/check-gui-theme-contract.py`
3. targeted GUI capture:
   - `powershell -ExecutionPolicy Bypass -File dev-tools/capture-python-gui-apps.ps1 -OnlyApps <app_id>`
4. inspect:
   - `Diagnostics/gui_capture_log.md`
   - `Diagnostics/gui_captures/<category>/<app_id>.png`

## Manifest Checks

Confirm:

- `framework` is `pyside6`
- `shared_theme` is `contexthub`
- `template` is set explicitly
- `manual.md` exists

## Visual Checks

Confirm:

- header only shows app name and icon buttons
- non-mini windows show bottom-right grip
- card gaps do not expose incorrect shell colors
- no raw-color drift was added
- compact windows do not become scroll-heavy unless the product truly requires it

## If Visual Issues Appear

Check in this order:

1. saved geometry overriding the new default size
2. `QScrollArea.viewport()` lacking `surfaceRole="content"`
3. `QSplitter::handle` exposing a mismatched surface
4. local stylesheet overrides
5. template mismatch, such as a `compact` app behaving like `full`
