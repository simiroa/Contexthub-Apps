from __future__ import annotations

import sys
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parent
REPO_ROOT = APP_ROOT.parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from runtime_bootstrap import resolve_shared_runtime

ENGINE_ROOT = APP_ROOT.parent / "_engine"
SHARED_ROOT, SHARED_PACKAGE_ROOT = resolve_shared_runtime(APP_ROOT)
for path in (ENGINE_ROOT, SHARED_ROOT, SHARED_PACKAGE_ROOT):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from contexthub.ui.qt.shell import (
    HeaderSurface,
    apply_app_icon,
    attach_size_grip,
    build_shell_stylesheet,
    get_shell_metrics,
)

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication, QFrame, QLabel, QMainWindow, QVBoxLayout, QWidget

APP_ID = "__APP_ID__"
APP_TITLE = "__APP_NAME__"
APP_SUBTITLE = "__APP_DESCRIPTION__"


class SpecialTemplateWindow(QMainWindow):
    def __init__(self, app_root: Path) -> None:
        super().__init__()
        self.app_root = app_root
        self.setWindowTitle(APP_TITLE)
        self.setWindowFlags(Qt.Window | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.resize(1280, 860)
        self.setMinimumSize(1024, 760)
        apply_app_icon(self, self.app_root)
        self.setStyleSheet(build_shell_stylesheet())
        self._build_ui()

    def _build_ui(self) -> None:
        m = get_shell_metrics()
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(m.shell_margin - 2, m.shell_margin - 2, m.shell_margin - 2, m.shell_margin - 2)

        self.window_shell = QFrame()
        self.window_shell.setObjectName("windowShell")
        shell_layout = QVBoxLayout(self.window_shell)
        shell_layout.setContentsMargins(m.shell_margin, m.shell_margin, m.shell_margin, m.shell_margin)
        shell_layout.setSpacing(m.section_gap)

        header = HeaderSurface(self, APP_TITLE, APP_SUBTITLE, self.app_root)
        header.set_header_visibility(show_subtitle=False, show_asset_count=False, show_runtime_status=False)
        shell_layout.addWidget(header)

        workspace = QFrame()
        workspace.setObjectName("card")
        workspace_layout = QVBoxLayout(workspace)
        workspace_layout.setContentsMargins(m.panel_padding, m.panel_padding, m.panel_padding, m.panel_padding)
        title = QLabel("Special Workspace")
        title.setObjectName("sectionTitle")
        workspace_layout.addWidget(title)
        workspace_layout.addWidget(QLabel("Replace this area with the bespoke interaction model while keeping header/theme/grip rules."))
        shell_layout.addWidget(workspace, 1)

        attach_size_grip(shell_layout, self.window_shell)
        root.addWidget(self.window_shell)


def start_app(targets: list[str] | None = None) -> int:
    app = QApplication.instance() or QApplication(sys.argv)
    window = SpecialTemplateWindow(APP_ROOT)
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(start_app())
