# __APP_NAME__

## Purpose

Describe the single focused task this mini app performs.

## Inputs

- Explain accepted file or text input.

## Output

- Explain what the app changes, creates, or launches.

## Notes

- Keep this manual short.
