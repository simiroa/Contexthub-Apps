---
name: qt-app-builder-contexthub
description: Create new Contexthub Qt apps using the shared runtime, unified template rules, and the mini/compact/full/special template system. Use when adding or rewriting a PySide6 app in Contexthub-Apps.
---

# Qt App Builder For Contexthub

Use this skill when the task is to add a new Qt app, rewrite an old Qt app, or replace an outdated starter template inside `Contexthub-Apps`.

This skill is for `PySide6` apps only. It assumes the app must follow the shared Qt runtime and the current GUI contract in the repo.

## What This Skill Enforces

You must build new Qt apps around the shared runtime, not around app-local ad hoc styling.

Required:

- `ui.framework = pyside6`
- `ui.shared_theme = contexthub`
- `ui.template` explicitly set to `mini`, `compact`, `full`, or `special`
- `manual.md` present
- `HeaderSurface` used for the window header
- non-mini templates use `attach_size_grip()`
- shared shell stylesheet/palette/metrics imported from `contexthub.ui.qt.shell`
- color and surface decisions expressed through shared role/tone helpers

Forbidden:

- raw hex colors in app-local Qt stylesheets
- app-local `rgb(...)` or `rgba(...)` colors for normal UI styling
- custom header designs that add subtitle rows, open buttons, or extra badges by default
- special-case theme names for Qt apps
- mini/compact/full apps starting from old `customtkinter` templates

## Workflow

1. Determine category and whether existing category `_engine` can be reused.
2. Choose the template bucket using `references/template-selection.md`.
3. Copy the closest template asset from `assets/templates/`.
4. Assemble the app from the standard component blocks in `assets/components/`.
5. Fill `manifest.json`, `main.py`, and `manual.md`.
6. If shared runtime behavior is missing, add a shared role/helper instead of styling around it locally.
7. Validate with `references/validation-checklist.md`.

## Template Rules

- `mini`: very short single-task window, no bottom grip, minimal body.
- `compact`: one-column flow for input, status, and execution, non-mini grip.
- `full`: denser multi-panel or splitter layout, non-mini grip.
- `special`: bespoke interaction model allowed, but header/theme/grip contract still applies. Keep the template skeleton minimal; the main body should usually be replaced by app-specific components rather than a fixed standard layout.

Read these references before drafting code:

- `references/template-selection.md`
- `references/component-catalog.md`
- `references/component-roadmap.md`
- `references/implementation-patterns.md`
- `references/template-component-matrix.md`
- `references/theme-contract.md`
- `references/runtime-deps.md`
- `references/template-diffs.md`
- `references/validation-checklist.md`

## Output Contract

When using this skill, always produce a decision-complete creation spec before or alongside implementation. The spec must include:

- selected `ui.template`
- target category and why
- files to create or modify
- `_engine` reuse plan
- manifest-required fields
- shared UI rules being applied
- validation commands

## Template Asset Notes

The files under `assets/templates/` are starter skeletons for copy-and-fill work. They are intentionally placeholder-based and are not meant to be packaged unchanged.
The files under `assets/components/` are reusable component snippets for assembling those templates without inventing new layout conventions.
They include generic structure blocks, domain previews, queue-management blocks, channel/preset helpers, and result-inspection helpers.

For visual review of the current template buckets, launch:

- `python C:\Users\HG\.codex\skills\qt-app-builder-contexthub\template-example.py --template launcher`
- `python C:\Users\HG\.codex\skills\qt-app-builder-contexthub\template-example.py --template all`

Replace these placeholders after copying:

- `__APP_ID__`
- `__APP_NAME__`
- `__APP_DESCRIPTION__`
- `__CATEGORY__`
- `__EXTENSION__`
- `__AUTHOR__`
- `__VERSION__`
- `__ENGINE_MODULE__`

## When To Prefer Shared Runtime Extensions

If the design needs a new badge, panel tone, content surface, preview role, or shell behavior, extend `contexthub.ui.qt.shell` or `panels.py` first. Do not solve shared problems in a single app.

## Review And Self-Check

Before finalizing a generated app plan or implementation, compare the proposed structure against the current bucket examples and write down:

- why the chosen template fits better than the adjacent buckets
- which standard components are being reused
- what, if anything, is truly bespoke

Use `references/review-worksheet.md` as the reporting format when doing a formal skill review.
