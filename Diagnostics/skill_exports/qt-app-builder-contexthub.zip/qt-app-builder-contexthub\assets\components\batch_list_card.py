from __future__ import annotations

from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QListWidget, QPushButton, QVBoxLayout

from contexthub.ui.qt.shell import get_shell_metrics, set_button_role


def build_batch_list_card(title: str = "Batch Items") -> dict[str, object]:
    m = get_shell_metrics()
    card = QFrame()
    card.setObjectName("card")
    layout = QVBoxLayout(card)
    layout.setContentsMargins(m.panel_padding, m.panel_padding, m.panel_padding, m.panel_padding)
    layout.setSpacing(10)

    title_label = QLabel(title)
    title_label.setObjectName("sectionTitle")
    layout.addWidget(title_label)

    list_widget = QListWidget()
    layout.addWidget(list_widget, 1)

    actions = QHBoxLayout()
    add_btn = QPushButton("Add")
    remove_btn = QPushButton("Remove")
    clear_btn = QPushButton("Clear")
    set_button_role(add_btn, "secondary")
    set_button_role(remove_btn, "secondary")
    set_button_role(clear_btn, "secondary")
    actions.addWidget(add_btn)
    actions.addWidget(remove_btn)
    actions.addWidget(clear_btn)
    actions.addStretch(1)
    layout.addLayout(actions)

    return {
        "card": card,
        "list_widget": list_widget,
        "add_btn": add_btn,
        "remove_btn": remove_btn,
        "clear_btn": clear_btn,
    }
