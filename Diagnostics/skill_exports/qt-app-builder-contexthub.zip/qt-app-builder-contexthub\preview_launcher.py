from __future__ import annotations

import argparse
import sys
from pathlib import Path


SKILL_ROOT = Path(__file__).resolve().parent


def _resolve_repo_root() -> Path:
    candidates = [
        Path.cwd(),
        Path.home() / "Documents" / "Contexthub-Apps",
        Path("C:/Users/HG/Documents/Contexthub-Apps"),
    ]
    for candidate in candidates:
        if (candidate / "agent-docs" / "gui-runtime-contract.md").exists():
            return candidate
    raise RuntimeError("Contexthub-Apps repository root not found for template preview launcher.")


REPO_ROOT = _resolve_repo_root()
SHARED_ROOT = REPO_ROOT / "dev-tools" / "runtime" / "Shared"

for path in (SKILL_ROOT, SHARED_ROOT):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication, QFrame, QHBoxLayout, QLabel, QMainWindow, QPushButton, QVBoxLayout, QWidget
from contexthub.ui.qt.panels import ExportFoldoutPanel, PresetParameterPanel, QueueManagerPanel, ResultInspectorPanel

from assets.components.batch_list_card import build_batch_list_card
from assets.components.compare_workspace import build_compare_workspace
from assets.components.execution_card import build_execution_card
from assets.components.input_card import build_input_card
from assets.components.output_options_card import build_output_options_card
from assets.components.parameter_strip import build_parameter_strip
from assets.components.preview_card import build_preview_card
from assets.components.prompt_card import build_prompt_card
from assets.components.shell_frame import build_shell_window, finish_shell_window
from assets.components.status_card import build_status_card
from assets.components.video_preview_card import build_video_preview_card
from assets.components.workspace_split import build_workspace_split
from contexthub.ui.qt.shell import get_shell_metrics, set_surface_role


def _set_card_stretch(card: QFrame, stretch: int = 1) -> None:
    card.setSizePolicy(card.sizePolicy().horizontalPolicy(), card.sizePolicy().verticalPolicy())
    card.layout().setStretch(card.layout().count() - 1, stretch)


class TemplatePreviewWindow(QMainWindow):
    def __init__(self, title: str, *, size: tuple[int, int], minimum: tuple[int, int], use_size_grip: bool) -> None:
        super().__init__()
        self.app_root = SKILL_ROOT
        self.use_size_grip = use_size_grip
        self.setWindowTitle(title)
        self.setWindowFlags(Qt.Window | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.resize(*size)
        self.setMinimumSize(*minimum)
        _, self.window_shell, self.shell_layout = build_shell_window(
            self,
            self.app_root,
            title,
            "Qt App Builder Preview",
            use_size_grip=False,
        )

    def finalize_shell(self) -> None:
        finish_shell_window(self.shell_layout, self.window_shell, use_size_grip=self.use_size_grip)


class MiniPreviewWindow(TemplatePreviewWindow):
    def __init__(self) -> None:
        super().__init__("Mini Template", size=(420, 320), minimum=(380, 280), use_size_grip=False)
        summary_card, summary_label = build_status_card("Selection Summary", "3 files selected. Ready to run one focused action.")
        summary_label.setWordWrap(True)
        self.shell_layout.addWidget(summary_card)

        run = build_execution_card("Run")
        run["output_edit"].setText("Selection-only action")
        run["output_edit"].setEnabled(False)
        run["open_btn"].setVisible(False)
        run["status"].setText("Confirm and execute")
        self.shell_layout.addWidget(run["card"])
        self.finalize_shell()


class CompactPreviewWindow(TemplatePreviewWindow):
    def __init__(self) -> None:
        super().__init__("Compact Template", size=(720, 820), minimum=(620, 740), use_size_grip=True)
        source_card, field, button = build_input_card("Source URL", "Paste a source URL or file path", "Analyze")
        field.setText("https://example.com/sample")
        button.setEnabled(False)
        self.shell_layout.addWidget(source_card)

        preview = build_preview_card("Inspect Current Source", "Preview")
        preview["meta_label"].setText("One preview or one list only. Keep the flow vertical and immediately understandable.")
        self.shell_layout.addWidget(preview["card"])

        options = build_output_options_card("Run Options")
        options["format_combo"].addItems(["Default", "High Quality", "Draft"])
        options["prefix_edit"].setText("compact_demo")
        self.shell_layout.addWidget(options["card"])

        run = build_execution_card("Export")
        run["output_edit"].setText(r"C:\Output\compact_demo")
        run["status"].setText("Integrated options + execution")
        self.shell_layout.addWidget(run["card"])
        self.finalize_shell()


class FullPreviewWindow(TemplatePreviewWindow):
    def __init__(self) -> None:
        super().__init__("Full Template", size=(1280, 900), minimum=(1024, 760), use_size_grip=True)
        left = QWidget()
        set_surface_role(left, "content")
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(get_shell_metrics().section_gap)

        preview = build_video_preview_card("Preview")
        preview["meta_label"].setText("Preview first. Keep the current visual target above the input batch.")
        left_layout.addWidget(preview["card"], 1)

        batch = build_batch_list_card("Input Batch")
        for name in ("shot010.exr", "shot020.exr", "shot030.exr"):
            batch["list_widget"].addItem(name)
        left_layout.addWidget(batch["card"], 1)

        right = QWidget()
        set_surface_role(right, "content")
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(get_shell_metrics().section_gap)

        settings = PresetParameterPanel("Settings")
        settings.description_label.setText("When presets exist, keep the preset dropdown and core parameters in one card.")
        settings.preset_combo.addItems(["Web MP4", "Edit Proxy", "Master ProRes 422"])
        settings.preset_combo.setCurrentIndex(0)
        settings.profile_combo.addItems(["H.264 High", "H.264 Low/Proxy", "ProRes 422"])
        settings.scale_combo.addItems(["100%", "75%", "50%"])
        settings.slider.setRange(0, 100)
        settings.slider.setValue(82)
        settings.slider_value.setText("82")
        settings.smart_toggle.setChecked(True)
        right_layout.addWidget(settings)

        quality = build_parameter_strip("Bitrate Bias")
        quality["slider"].setRange(0, 100)
        quality["slider"].setValue(68)
        quality["value_label"].setText("68")
        right_layout.addWidget(quality["card"])

        inspector = ResultInspectorPanel("Result Inspector")
        inspector.key_list.addItems(["Video", "Audio", "Container", "Warnings"])
        inspector.detail_text.setPlainText("Selected result details appear here.")
        right_layout.addWidget(inspector, 1)

        export_section = ExportFoldoutPanel("Export")
        export_section.status_label.setText("Preset > parameters > export")
        export_section.progress_label.setText("Output path, format, and run controls live in the foldout.")

        output = build_output_options_card("Output Options")
        output["format_combo"].addItems(["ProRes 422 HQ", "H.264 MP4", "EXR Sequence"])
        output["prefix_edit"].setText("full_demo")
        export_section.details_layout.insertWidget(0, output["card"])

        run = build_execution_card("Render")
        run["output_edit"].setText(r"C:\Output\full_demo")
        run["status"].setText("Ready to export")
        run["open_btn"].setVisible(False)
        run["run_btn"].setVisible(False)
        export_section.details_layout.insertWidget(1, run["card"])
        right_layout.addWidget(export_section)

        splitter = build_workspace_split(left, right, sizes=(720, 520))
        self.shell_layout.addWidget(splitter, 1)
        self.finalize_shell()


class SpecialPreviewWindow(TemplatePreviewWindow):
    def __init__(self) -> None:
        super().__init__("Special Template", size=(1280, 880), minimum=(1024, 760), use_size_grip=True)
        workspace = build_compare_workspace("Workspace A", "Workspace B")

        left_layout = workspace["left"].layout()
        right_layout = workspace["right"].layout()
        if left_layout.count():
            item = left_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        if right_layout.count():
            item = right_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(get_shell_metrics().section_gap)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(get_shell_metrics().section_gap)

        prompt = build_prompt_card("Prompt / Criteria")
        prompt["editor"].setPlainText("Special apps can be bespoke, but they should still be built from shared header, theme, grip, and role-based surfaces.")
        left_layout.addWidget(prompt["card"])

        queue = QueueManagerPanel("Processing Queue")
        queue.count_label.setText("4")
        queue.list_widget.addItems(["Task A", "Task B", "Task C", "Task D"])
        left_layout.addWidget(queue, 1)

        inspector = ResultInspectorPanel("Inspector")
        inspector.key_list.addItems(["Score", "Reasoning", "Assets", "Logs"])
        inspector.detail_text.setPlainText("Special templates keep bespoke interaction, not bespoke theme rules.")
        right_layout.addWidget(inspector, 1)

        summary, label = build_status_card("Special Rule", "Use this bucket only when compact/full cannot describe the interaction model.")
        label.setWordWrap(True)
        right_layout.addWidget(summary)

        self.shell_layout.addWidget(workspace["splitter"], 1)
        self.finalize_shell()


class LauncherWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("Qt Template Preview Launcher")
        self.resize(420, 260)
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        title = QLabel("Qt App Builder Template Preview")
        title.setObjectName("sectionTitle")
        layout.addWidget(title)

        summary = QLabel("Open the current mini, compact, full, and special template demos as actual Qt windows.")
        summary.setWordWrap(True)
        summary.setObjectName("summaryText")
        layout.addWidget(summary)

        buttons = QVBoxLayout()
        buttons.setSpacing(8)
        self.windows: list[QMainWindow] = []
        for label, factory in (
            ("Open Mini", MiniPreviewWindow),
            ("Open Compact", CompactPreviewWindow),
            ("Open Full", FullPreviewWindow),
            ("Open Special", SpecialPreviewWindow),
        ):
            btn = QPushButton(label)
            btn.clicked.connect(lambda _checked=False, f=factory: self.open_window(f))
            buttons.addWidget(btn)
        open_all = QPushButton("Open All")
        open_all.clicked.connect(self.open_all)
        buttons.addWidget(open_all)
        layout.addLayout(buttons)
        layout.addStretch(1)

    def open_window(self, factory: type[QMainWindow]) -> None:
        window = factory()
        window.show()
        self.windows.append(window)

    def open_all(self) -> None:
        for factory in (MiniPreviewWindow, CompactPreviewWindow, FullPreviewWindow, SpecialPreviewWindow):
            self.open_window(factory)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Open Qt template previews for the Contexthub skill.")
    parser.add_argument(
        "--template",
        choices=("mini", "compact", "full", "special", "all", "launcher"),
        default="launcher",
        help="Which preview to open.",
    )
    args = parser.parse_args(argv)

    app = QApplication.instance() or QApplication(sys.argv)

    if args.template == "mini":
        window: QMainWindow = MiniPreviewWindow()
        window.show()
    elif args.template == "compact":
        window = CompactPreviewWindow()
        window.show()
    elif args.template == "full":
        window = FullPreviewWindow()
        window.show()
    elif args.template == "special":
        window = SpecialPreviewWindow()
        window.show()
    elif args.template == "all":
        launcher = LauncherWindow()
        launcher.show()
        launcher.open_all()
        window = launcher
    else:
        window = LauncherWindow()
        window.show()

    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
