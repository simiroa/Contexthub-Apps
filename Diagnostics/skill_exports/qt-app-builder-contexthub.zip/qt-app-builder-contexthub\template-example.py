from preview_launcher import main


if __name__ == "__main__":
    raise SystemExit(main())
