# Theme Contract

All new Qt apps in `Contexthub-Apps` must use the shared Qt theme contract.

## Required Imports

Start from shared runtime APIs instead of app-local styling:

- `HeaderSurface`
- `build_shell_stylesheet`
- `get_shell_metrics`
- `get_shell_palette`
- `attach_size_grip`
- `set_surface_role`
- `set_button_role`
- `set_badge_role`

## Header Rules

The default header is fixed:

- app name only
- icon buttons only on the right
- no subtitle row
- no open button
- no extra runtime/asset badges by default

Use `HeaderSurface` and hide optional elements rather than redesigning the header.

## Grip Rules

- `mini`: no size grip
- `compact`, `full`, `special`: use `attach_size_grip(shell_layout, window_shell)`

Do not hand-build custom grip rows in new apps.

## Color Rules

Use shared palette and role/tone helpers.

Allowed:

- `set_surface_role(widget, "card")`
- `set_surface_role(widget, "content")`
- `set_button_role(button, "secondary")`
- `set_badge_role(label, "status", "warning")`

Forbidden:

- `setStyleSheet("background: #123456; ...")`
- `setStyleSheet("border: 1px solid rgba(...)")` for ordinary theme work
- local alternate palette systems

## Content Gap Rules

When card gaps or empty scroll regions appear:

- use `surfaceRole="content"` on body containers and scroll viewports
- use `subtle` for inset previews or secondary wells
- avoid large-area `field_bg` usage

## Shared Theme Identity

All Qt apps must declare:

- `"framework": "pyside6"`
- `"shared_theme": "contexthub"`

No other Qt theme name is valid for new work.
